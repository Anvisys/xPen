﻿var Math = function () {
    function add(left, right) { return left + right; }

    return (add, add);
};